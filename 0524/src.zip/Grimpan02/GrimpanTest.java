package Grimpan02;

public class GrimpanTest {
    public static void main(String[] args) {
        new MyFrame();
    }
}
