package exam01;

public class StringBufferTest {
    public static void main(String[] args) {
        StringBuffer sb = new StringBuffer("hello");
        System.out.println(sb);
        sb.append(" Java");
        System.out.println(sb);
    }
}
