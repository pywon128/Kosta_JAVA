//class BankAccount{
//    private String name;
//    private String accountNumber;
//    int money;
//    double rate;
//
//    public BankAccount(String name, String accountNumber, int money, double rate) {
//        this.name = name;
//        this.accountNumber = accountNumber;
//        this.money = money;
//        this.rate = rate;
//    }
//    public BankAccount(){}
//
//    public String getName() {
//        return name;
//    }
//    public void setName(String name) {
//        this.name = name;
//    }
//    public String getAccountNumber() {
//        return accountNumber;
//    }
//    public void setAccountNumber(String accountNumber) {
//        this.accountNumber = accountNumber;
//    }
//    public int getMoney() {
//        return money;
//    }
//    public void setMoney(int money) {
//        this.money = money;
//    }
//    public double getRate() {
//        return rate;
//    }
//    public void setRate(double rate) {
//        this.rate = rate;
//    }
//}
//
//public class BankAccountTest {
//    public static void main(String[] args) {
//        BankAccount bA1 = new BankAccount();
//        BankAccount bA2 = new BankAccount("bA2","1111-111-11-1",500,4.5);
//
//        System.out.println("생성자 매개변수가 없는 객체\n" +
//                "이름 : "+bA1.getName()+" 계좌번호 : "+bA1.getAccountNumber()+" 잔액 : "+bA1.getMoney()+" 이자율 : "+bA1.getRate());
//        System.out.println("생성자 매개변수가 있는 객체\n" +
//                "이름 : "+bA2.getName()+" 계좌번호 : "+bA2.getAccountNumber()+" 잔액 : "+bA2.getMoney()+" 이자율 : "+bA2.getRate());
//
//
//    }`
//}
