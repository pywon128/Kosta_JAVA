//class Person{
//    private String name;
//    private int age;
//    private double height;
//
//    public String getName() {
//        return name;
//    }
//    public int getAge() {
//        return age;
//    }
//    public double getHeight() {
//        return height;
//    }
//
//    public Person(String name, int age, double height) {
//        this.name = name;
//        this.age = age;
//        this.height = height;
//    }
//}
//
//public class PersonTest2 {
//    public static void main(String[] args) {
//        // 사용자가 생성자를 만들기 시작하면 더이상 기본생성자를 제공하지 않음
//        // 필요하다면 사용자가 만들어서 사용해야 함
//        Person p = new Person();
//        System.out.println(p.getName()+", "+p.getAge()+", "+p.getHeight());
//    }
//}
