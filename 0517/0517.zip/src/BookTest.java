//class Book{
//    private String title;
//    private String author;
//
//    public void setTitle(String title) {
//        this.title = title;
//    }
//}
//
//public class BookTest {
//    public static void main(String[] args){
//        Book b1 = new Book();
//        Book b2 = new Book();
////      b1.title="재미있는 자바";
////        ㄴ private 영역의 맴버변수에 직접 접근 x
////           public 에 있는 메서드를 통해 접근하도록 해야함
////        set 메서드 = 접근해서 값을 변경시키는 메서드 = 설정자
////        get 메서드 = 접근해서 값을 읽어오는 메서드 = 접근자
//
//    }
//}
