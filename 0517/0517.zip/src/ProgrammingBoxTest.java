public class ProgrammingBoxTest {
    public static void main(String[] args) {

        ProgrammingBox b1 = new ProgrammingBox();
        System.out.println(b1.toString());

        ProgrammingBox b2 = new ProgrammingBox(5,5,5,true);
        System.out.println(b2.toString());

    }
}
