public class ProgrammingDogTest {
    public static void main(String[] args) {
        ProgrammingDog d2 = new ProgrammingDog();
        System.out.println(d2.toString());

        ProgrammingDog d1 = new ProgrammingDog("뽀삐","웰시코기",2);
        System.out.println(d1.toString());


    }
}
