//class Person{
//    private String name;
//    private int age;
//    private double height;
//
//    public String getName() {
//        return name;
//    }
//    public int getAge() {
//        return age;
//    }
//    public double getHeight() {
//        return height;
//    }
//}
//
//public class PersonTest {
//    public static void main(String[] args) {
//        Person p = new Person();
//        System.out.println(p.getName()+", "+p.getAge()+", "+p.getHeight());
//    }
//}
