//class Book{
//    private String title;
//    private String author;
//
//    // 생성자
//    public Book(){
//        System.out.println("생성자 동작");
//        title = "재미있는 자바";
//        author = "java";
//    }
//
//    public void setTitle(String title) {
//        this.title = title;
//    }
//    public void setAuthor(String author) { this.author = author; }
//    public String getTitle() { return title; }
//    public String getAuthor() { return author; }
//}
//
//public class BookTest3 {
//    public static void main(String[] args) {
//        Book b1 = new Book();
////        b1.setTitle("재미있는 자바");
////        b1.setAuthor("bob");
//        System.out.println(b1.getTitle());
//        System.out.println(b1.getAuthor());
//    }
//}