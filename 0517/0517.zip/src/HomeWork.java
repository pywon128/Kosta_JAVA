public class HomeWork {
    private String name;
    private String birds;
    private int age;




}
