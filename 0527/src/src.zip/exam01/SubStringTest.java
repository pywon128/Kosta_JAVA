package exam01;

public class SubStringTest {
    public static void main(String[] args) {
        String data = "java";
        String data2 = data.substring(3,4);
        String data3 = data.substring(1);
        System.out.println("data2 = " + data2);
        System.out.println("data3 = " + data3);
    }
}
