package exam01;

public class IndexOfTest {
    public static void main(String[] args) {
        String data = "HelloJava";
        int cnt = data.indexOf("e");
        System.out.println(cnt);
        int cnt2 = data.indexOf("Java");
        System.out.println(cnt2);

    }
}
