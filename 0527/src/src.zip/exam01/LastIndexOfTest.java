package exam01;

public class LastIndexOfTest {
    public static void main(String[] args) {
        String data = "java";
        int n = data.indexOf("a");
        int n2 = data.lastIndexOf("a");

        System.out.println(n);
        System.out.println(n2);
    }
}
