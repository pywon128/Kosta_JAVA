package exam01;

public class IndexOfTest2 {
    public static void main(String[] args) {
        String data = "Hello Java Hello Oracle";
        int n = data.indexOf("Hello",1);
        System.out.println(n);
    }
}