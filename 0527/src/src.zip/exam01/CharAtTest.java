package exam01;

public class CharAtTest {
    public static void main(String[] args) {
        String data = "Hello java";
        String nmae = "name";
        String year = "2024";

        char c1 = data.charAt(0);
        int c2 = year.charAt(0);
        int c3 = Integer.parseInt(year.charAt(0)+"");


    }
}