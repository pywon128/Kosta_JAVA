package exam01;

public class PersonTest {
    public static void main(String[] args) {
        Person p = new Person("김유신");
        p.sayHello();
        Person p2 = new Person("이순신");
        p2.sayHello();
    }
}
