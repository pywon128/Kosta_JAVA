package exam06;

import exam05.CountDownEvent;

public class CountDownEventTest {
    public static void main(String[] args) {
        CountDownEvent c = new CountDownEvent();

        c.start();
    }
}
