package exam09;

public class Boom extends Enermy {
    public Boom(String fileName) {
        super(fileName);

        x = -100;
        y = -100;
//        System.out.println(super.x);
//        System.out.println(super.y);
    }

    public void setX(int x){
        this.x = x;
    }
    public void setY(int y){
        this.y = y;
    }
}
